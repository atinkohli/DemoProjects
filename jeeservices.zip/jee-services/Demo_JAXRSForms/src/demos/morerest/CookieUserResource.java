package demos.morerest;

import javax.ws.rs.Consumes;
import javax.ws.rs.CookieParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

@Path("/service/cookieusers")
public class CookieUserResource {

    @GET
    @Produces("text/plain")
    public String getText(@CookieParam("UserFavColour")@DefaultValue("Green")String fav) {
        return "Favourite colour: " + fav;
    }
}
