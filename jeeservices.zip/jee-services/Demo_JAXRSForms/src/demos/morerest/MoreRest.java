package demos.morerest;

import java.util.Set;
import java.util.HashSet;
import javax.ws.rs.core.Application;

import demos.morerest.crud.ProductApiResource;
import demos.morerest.crud.ProductFormResource;

public class MoreRest extends Application {

	private Set<Object> singletons = new HashSet<Object>();
	private Set<Class<?>> empty = new HashSet<Class<?>>();
	public MoreRest(){
	     singletons.add(new Start());
	     singletons.add(new CookieUserResource());	     
	     singletons.add(new FormUserResource());
	     singletons.add(new HeaderUserResource());
	     singletons.add(new HttpInfoUserResource());
	     singletons.add(new MultipleVariablesUserResource());
	     singletons.add(new PatternedUserResource());
	     singletons.add(new QueryStringUserResource());
	     singletons.add(new UserResource());
	     singletons.add(new ProductApiResource());
	     singletons.add(new ProductFormResource());
	}
	@Override
	public Set<Class<?>> getClasses() {
	     return empty;
	}
	@Override
	public Set<Object> getSingletons() {
	     return singletons;
	}
}
