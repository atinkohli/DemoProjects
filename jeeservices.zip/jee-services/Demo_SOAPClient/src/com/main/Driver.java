package com.main;

import java.rmi.RemoteException;

import com.soap.services.CalculatorProxy;

public class Driver {

	public static void main(String[] args) throws RemoteException {

		CalculatorProxy proxy = new CalculatorProxy();
		
		System.out.format("Adding 10 + 20 gives %d%n", proxy.add(10,20));
	}

}
