package com.travel.client;

import java.rmi.RemoteException;
import java.util.List;

import com.travel.service.Hotel;
import com.travel.service.TravelServiceProxy;

public class ClientDriver {

	public static void main(String[] args) throws RemoteException {
		TravelServiceProxy proxy = new TravelServiceProxy();
		Hotel hotel = new Hotel();
		hotel.setCity("Athlone");
		hotel.setName("Radisson");
		hotel.setNumberRooms(200);
		hotel.setRating(4);
		
		proxy.addHotel(hotel);
		
		Hotel[] hotels = proxy.getHotels();
		
		for(Hotel h : hotels){
			System.out.println(h.getCity());
		}
	}

}
