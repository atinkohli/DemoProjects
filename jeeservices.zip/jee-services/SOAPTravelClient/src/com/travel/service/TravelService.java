/**
 * TravelService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.travel.service;

public interface TravelService extends java.rmi.Remote {
    public com.travel.service.Hotel[] getHotels() throws java.rmi.RemoteException;
    public void addHotel(com.travel.service.Hotel arg0) throws java.rmi.RemoteException;
}
