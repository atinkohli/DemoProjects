/**
 * TravelServiceService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.travel.service;

public interface TravelServiceService extends javax.xml.rpc.Service {
    public java.lang.String getTravelServicePortAddress();

    public com.travel.service.TravelService getTravelServicePort() throws javax.xml.rpc.ServiceException;

    public com.travel.service.TravelService getTravelServicePort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
