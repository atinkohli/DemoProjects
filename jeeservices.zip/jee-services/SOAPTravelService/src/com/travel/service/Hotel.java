package com.travel.service;

public class Hotel {
	private String name;
	private String city;
	private int rating;
	private int numberRooms;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	public int getNumberRooms() {
		return numberRooms;
	}
	public void setNumberRooms(int numberRooms) {
		this.numberRooms = numberRooms;
	}
	
	
}
