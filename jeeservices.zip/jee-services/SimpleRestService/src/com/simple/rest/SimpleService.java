package com.simple.rest;

import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.Path;

@Path("/SimpleService")
public class SimpleService {

	@GET()
	@Produces("text/plain")
	public String sayHello() {
	    return "Hello World!";
	}

	@GET()
	@Produces("text/plain")
	@Path("/Time")
	public String getTime() {
	    return new java.util.Date().toString();
	}

}
