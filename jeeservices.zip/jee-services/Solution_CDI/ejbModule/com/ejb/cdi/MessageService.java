package com.ejb.cdi;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.inject.Named;

import com.ejb.cdi.providers.MessageProvider;
import com.ejb.cdi.qualifiers.Casual;

/**
 * Session Bean implementation class MessageService
 */
@Stateless
public class MessageService implements MessageServiceRemote {


	@Inject()
	@Casual
	private MessageProvider messageProvider;
	
	
	public MessageService() {
    }

	
	public String getMessage(){
		return messageProvider.getMessage();
	}
}
