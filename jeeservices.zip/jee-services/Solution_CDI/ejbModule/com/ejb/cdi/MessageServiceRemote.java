package com.ejb.cdi;

import javax.ejb.Remote;

@Remote
public interface MessageServiceRemote {
	public String getMessage();
}
