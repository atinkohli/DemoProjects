package com.ejb.cdi.decorators;

import javax.decorator.Decorator;
import javax.decorator.Delegate;
import javax.enterprise.inject.Any;
import javax.inject.Inject;

import com.ejb.cdi.providers.MessageProvider;

@Decorator
public class QuotesMessageDecorator implements MessageProvider {

	@Inject
	@Delegate
	@Any
	private MessageProvider messageProvider;
	
	
	@Override
	public String getMessage() {
		return "\"" + messageProvider.getMessage() + "\"";
	}



}
