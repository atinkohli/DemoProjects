package com.ejb.cdi.providers;

import javax.inject.Named;

import com.ejb.cdi.qualifiers.Casual;

@Casual
public class CasualMessageProvider implements MessageProvider {

	public String getMessage() {
		return "A very casual message";
	}


}
