package com.ejb.cdi.providers;

public interface MessageProvider {
	public String getMessage();
}
