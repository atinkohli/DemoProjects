package com.ejb.cdi.providers;

import javax.inject.Named;


public class SimpleMessageProvider implements MessageProvider {

	@Override
	public String getMessage() {
		return "Hello World";
	}


}
