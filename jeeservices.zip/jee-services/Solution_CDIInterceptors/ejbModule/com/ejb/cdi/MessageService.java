package com.ejb.cdi;

import javax.ejb.Stateless;
import javax.inject.Inject;

import com.ejb.cdi.providers.MessageProvider;


/**
 * Session Bean implementation class MessageService
 */
@Stateless
public class MessageService implements MessageServiceRemote {


	@Inject
	private MessageProvider messageProvider;
	
	
	public MessageService() {
    }

	
	public String getMessage(){
		return messageProvider.getMessage();
	}
}
