package com.client;

import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;


import com.ejb.cdi.MessageServiceRemote;


public class Driver {

	/**
	 * @param args
	 * @throws NamingException 
	 */
	public static void main(String[] args) throws NamingException {
		Properties jndiProps = new Properties();
		jndiProps.put(Context.INITIAL_CONTEXT_FACTORY, "org.jboss.naming.remote.client.InitialContextFactory");
		jndiProps.put(Context.PROVIDER_URL,"remote://localhost:4447");
		jndiProps.put(Context.SECURITY_PRINCIPAL, "chris");
		jndiProps.put(Context.SECURITY_CREDENTIALS, "ccz123");
		Context ctx = new InitialContext(jndiProps);
		
	
		MessageServiceRemote messageService = (MessageServiceRemote)ctx.lookup("Solution_CDIInterceptors/MessageService!com.ejb.cdi.MessageServiceRemote");
		
		String message = messageService.getMessage();
		
		System.out.println("Received from message service : "+ message);
		
	}

}
