package com.ejb.event;

import javax.ejb.Stateless;
import javax.inject.Inject;

import com.ejb.event.providers.MessageProvider;


/**
 * Session Bean implementation class MessageService
 */
@Stateless
public class MessageService implements MessageServiceRemote {


	@Inject
	private MessageProvider messageProvider;
	
	
	public MessageService() {
    }

	
	public String getMessage(){
		return messageProvider.getMessage();
	}
}
