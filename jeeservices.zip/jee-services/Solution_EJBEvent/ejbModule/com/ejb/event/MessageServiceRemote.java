package com.ejb.event;

import javax.ejb.Remote;

@Remote
public interface MessageServiceRemote {
	public String getMessage();
}
