package com.ejb.event.events;

import javax.enterprise.event.Observes;

public class MessageListener {

	public void listenMessages(@Observes MessageRequestEvent event){
		System.out.println(event.getMessage());
	}
	
}
