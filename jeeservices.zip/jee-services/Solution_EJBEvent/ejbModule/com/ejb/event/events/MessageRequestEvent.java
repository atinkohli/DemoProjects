package com.ejb.event.events;

public class MessageRequestEvent {

	private String message;

	public MessageRequestEvent(String message) {
		this.message = message;
	}

	public String getMessage() {
		return message;
	}
	
	

}
