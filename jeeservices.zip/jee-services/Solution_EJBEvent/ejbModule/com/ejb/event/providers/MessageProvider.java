package com.ejb.event.providers;

public interface MessageProvider {
	public String getMessage();
}
