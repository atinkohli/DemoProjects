package com.ejb.event.providers;

import javax.enterprise.event.Event;
import javax.inject.Inject;

import com.ejb.event.events.MessageRequestEvent;


public class SimpleMessageProvider implements MessageProvider {

	@Inject
	private Event<MessageRequestEvent> events;
	
	@Override
	public String getMessage() {
		events.fire(new MessageRequestEvent("Message has been requested, sending "+ "Hello World"));
		return "Hello World";
	}


}
