package com.ejb.interceptors;

import javax.ejb.Stateless;
import javax.interceptor.Interceptors;

/**
 * Session Bean implementation class CurrencyConverter
 */
@Stateless
public class CurrencyConverter implements CurrencyConverterRemote {

	private static final double POUNDS_EURO_RATE = 1.19;
	
	public CurrencyConverter() {

    }


    @Interceptors(LoggingInterceptor.class)
	public double poundsToEuro(double pounds){
    	return pounds/POUNDS_EURO_RATE;
    }
}
