package com.ejb.interceptors;

import javax.ejb.Remote;

@Remote
public interface CurrencyConverterRemote {
    public double poundsToEuro(double pounds);

}
