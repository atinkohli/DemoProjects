package com.ejb.timers;

import java.util.Collection;

import javax.annotation.Resource;
import javax.ejb.ScheduleExpression;
import javax.ejb.Stateless;
import javax.ejb.Timeout;
import javax.ejb.Timer;
import javax.ejb.TimerService;

/**
 * Session Bean implementation class TimerExample
 */
@Stateless
public class TimerExample implements TimerExampleRemote {

	@Resource
	private TimerService timerService;
	

    public TimerExample() {
 
    
    }
    
    public String startTimer(){
    	ScheduleExpression schedule = new ScheduleExpression();
    	schedule.dayOfMonth("*");
    	schedule.dayOfWeek("*");
    	schedule.hour("*");
    	schedule.minute("*");
    	schedule.second("*/10");
    	Timer timer = timerService.createCalendarTimer(schedule);
    	return "timer message schedule is " + schedule.toString();
    }
    
    
    public void stopTimer(){
    	Collection<Timer> timers = timerService.getTimers();
    	for(Timer timer: timers){
    		timer.cancel();
    	}
    }
    
    
    
    @Timeout
    public void timeout(Timer timer){
    	System.out.println("Timer bean timed out");
    }

}
