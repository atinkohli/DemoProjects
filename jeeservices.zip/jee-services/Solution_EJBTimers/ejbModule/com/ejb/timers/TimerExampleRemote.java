package com.ejb.timers;

import javax.ejb.Remote;

@Remote
public interface TimerExampleRemote {
	public String startTimer();
	public void stopTimer();
}
