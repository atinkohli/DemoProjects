package com.client;

import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import com.ejb.interceptors.CurrencyConverterRemote;



public class Driver {

	/**
	 * @param args
	 * @throws NamingException 
	 */
	public static void main(String[] args) throws NamingException {
		Properties jndiProps = new Properties();
		jndiProps.put(Context.INITIAL_CONTEXT_FACTORY, "org.jboss.naming.remote.client.InitialContextFactory");
		jndiProps.put(Context.PROVIDER_URL,"remote://localhost:4447");
		jndiProps.put(Context.SECURITY_PRINCIPAL, "chris");
		jndiProps.put(Context.SECURITY_CREDENTIALS, "ccz123");
		Context ctx = new InitialContext(jndiProps);
		
	
		CurrencyConverterRemote converterBean = (CurrencyConverterRemote)ctx.lookup("Solution_EJBInterceptors/CurrencyConverter!com.ejb.interceptors.CurrencyConverterRemote");
		System.out.println("Starting timer, press any key to stop");
		
		double euros = converterBean.poundsToEuro(100.0);
		
		System.out.format("100.0 pounds is %.2f euros %n", euros);
		
		
	}

}
