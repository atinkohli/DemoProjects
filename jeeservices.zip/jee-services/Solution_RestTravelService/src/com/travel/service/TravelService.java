package com.travel.service;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;

import com.travel.domain.Hotel;

@Path("/TravelService")
public class TravelService {

	@GET()
	@Produces("text/plain")
	public String sayHello() {
	    return "Hello World!";
	}

	@GET()
	@Produces({"application/xml","application/json"})
	@Path("/destinations")
	public Hotel destinations() {
		return new Hotel();
	}
	
	@POST()
	@Consumes("application/json")
	@Path("/destinations")
	public Response saveDestinations(Hotel hotel) {
		System.out.println("Received hotel name is " + hotel.getName() + " city " + hotel.getCity());
		return Response.noContent().build();
		//	    return "<destinations><name>hawaii</name><name>los_angeles</name></destinations>";
	}
	
	
}
