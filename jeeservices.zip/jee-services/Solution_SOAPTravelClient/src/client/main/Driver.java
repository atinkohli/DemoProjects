package client.main;

import java.rmi.RemoteException;

import com.travel.soap.service.Hotel;
import com.travel.soap.service.TravelService;
import com.travel.soap.service.TravelServiceProxy;


public class Driver {

	/**
	 * @param args
	 * @throws RemoteException 
	 */
	public static void main(String[] args) throws RemoteException {

		TravelServiceProxy serviceFactory = new TravelServiceProxy();
		
		TravelService serviceProxy = serviceFactory.getTravelService();
		
		Hotel hotel = new Hotel("Athlone", "Radisson", 100, 4);
		
		serviceProxy.addHotel(hotel);
		
		Hotel[] hotels = serviceProxy.getHotels();
		
		for(Hotel h : hotels){
			System.out.format("%s %s %d %d %n", h.getName(), 
							h.getCity(),
							h.getNumberRooms(),
							h.getRating());

		}
		
	}

}
