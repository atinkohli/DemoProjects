/**
 * TravelService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.travel.soap.service;

public interface TravelService extends java.rmi.Remote {
    public void addHotel(com.travel.soap.service.Hotel arg0) throws java.rmi.RemoteException;
    public com.travel.soap.service.Hotel[] getHotels() throws java.rmi.RemoteException;
}
