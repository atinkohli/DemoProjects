package com.client;

import java.io.IOException;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import com.ejb.timers.TimerExampleRemote;

public class TimerClient {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws NamingException 
	 */
	public static void main(String[] args) throws IOException, NamingException {

		
		Properties jndiProps = new Properties();
		jndiProps.put(Context.INITIAL_CONTEXT_FACTORY, "org.jboss.naming.remote.client.InitialContextFactory");
		jndiProps.put(Context.PROVIDER_URL,"remote://localhost:4447");
		// create a context passing these properties
		jndiProps.put(Context.SECURITY_PRINCIPAL, "chris");
		// password
		jndiProps.put(Context.SECURITY_CREDENTIALS, "ccz123");

		jndiProps.put("jboss.naming.client.ejb.context", true);
		
		Context ctx = new InitialContext(jndiProps);
		
	
		TimerExampleRemote timerBean = (TimerExampleRemote)ctx.lookup("Solution_EJBTimers/TimerExample!com.ejb.timers.TimerExampleRemote");
		System.out.println("Starting timer, press any key to stop");
		
		String msg = timerBean.startTimer();
		
		System.out.println("Received from timer bean : "+ msg);
		
		int input = System.in.read();
		
		timerBean.stopTimer();
		
		System.out.println("Stopped timer");
		
	}

}
